package com.cg.product.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.bean.Product;
import com.cg.product.dao.IProductDao;

@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
IProductDao productdao;

	

		@Override
		public double CalDiscount(String proid) {

			Product pro=productdao.getProductById(proid);
			double originalPrice=pro.getPrice();
			double var1=originalPrice*pro.getQty();
		double remBal=(var1)-((pro.getDiscount()*var1)/100);	
		pro.setPrice(remBal);
		
		return remBal;
		
		}
	
	}

